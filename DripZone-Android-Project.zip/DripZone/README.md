# DripZone — Expo Android starter

Luxury streetwear shopping starter built with Expo, React Native, and TypeScript.

## Current features
- Eight sample streetwear products and USD prices
- Category filtering
- Add to cart, change quantities, and remove items
- Subtotal and estimated shipping calculation
- Checkout preview only (no real payment processing)

## Android phone + cloud build
You can build the Android App Bundle in Expo's cloud service. You need an Expo account and access to this project folder in a cloud development terminal such as GitHub Codespaces.

1. Install dependencies: `npm install`
2. Check the project: `npx expo-doctor`
3. Sign in to Expo: `npx eas-cli@latest login`
4. Configure EAS: `npx eas-cli@latest build:configure`
5. Start a signed production AAB build: `npx eas-cli@latest build --platform android --profile production`
6. Follow prompts to create or link the EAS project. If no Android signing key exists, choose to let EAS generate and manage it.
7. When the build finishes, download the `.aab` from the EAS build page.

The Android package ID is `com.dripzone.app`; keep it unchanged for this app's first Play Store release.

## Important before public launch
This starter is not yet a complete production commerce backend. Products are sample data, the cart is local state, and checkout is a placeholder. Before accepting real orders, add verified inventory, order storage, secure payment-provider checkout, shipping/tax handling, support contact, privacy policy, terms, and a refund policy. Never put secret API keys or payment secrets in the mobile app.
