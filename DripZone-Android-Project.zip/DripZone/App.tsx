import React, { useMemo, useState } from "react";
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

type Category = "All" | "Tees" | "Hoodies" | "Bottoms" | "Accessories";
type Product = {
  id: string;
  name: string;
  category: Exclude<Category, "All">;
  price: number;
  description: string;
  color: string;
  tag?: string;
};
type CartItem = { product: Product; quantity: number };

const PRODUCTS: Product[] = [
  { id: "tee-01", name: "DripZone Essential Tee", category: "Tees", price: 29, description: "Heavyweight everyday fit", color: "#DCE5D7", tag: "BESTSELLER" },
  { id: "tee-02", name: "Zone Graphic Tee", category: "Tees", price: 35, description: "Bold front graphic", color: "#E8DCCB", tag: "NEW" },
  { id: "hoodie-01", name: "Core Pullover Hoodie", category: "Hoodies", price: 65, description: "Soft fleece • relaxed fit", color: "#C7C9D2" },
  { id: "hoodie-02", name: "After Hours Hoodie", category: "Hoodies", price: 72, description: "Oversized streetwear silhouette", color: "#D7C7B8", tag: "NEW" },
  { id: "bottom-01", name: "Utility Cargo Pants", category: "Bottoms", price: 58, description: "Everyday utility pockets", color: "#C9D0BE" },
  { id: "bottom-02", name: "Zone Track Pants", category: "Bottoms", price: 48, description: "Tapered fit • elastic waist", color: "#D8D8D8" },
  { id: "acc-01", name: "DripZone Beanie", category: "Accessories", price: 22, description: "Rib-knit cuff beanie", color: "#C8B8A7" },
  { id: "acc-02", name: "Logo Crossbody Bag", category: "Accessories", price: 32, description: "Compact everyday carry", color: "#B8C4C5" },
];

const CATEGORIES: Category[] = ["All", "Tees", "Hoodies", "Bottoms", "Accessories"];
const money = (amount: number) => `$${amount.toFixed(2)}`;

export default function App() {
  const [category, setCategory] = useState<Category>("All");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);

  const visibleProducts = useMemo(
    () => category === "All" ? PRODUCTS : PRODUCTS.filter((p) => p.category === category),
    [category]
  );
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = subtotal === 0 || subtotal >= 100 ? 0 : 7.95;
  const total = subtotal + shipping;

  function addToCart(product: Product) {
    setCart((current) => {
      const found = current.find((item) => item.product.id === product.id);
      if (found) {
        return current.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...current, { product, quantity: 1 }];
    });
    Alert.alert("Added to bag", `${product.name} was added to your cart.`);
  }

  function changeQuantity(productId: string, delta: number) {
    setCart((current) =>
      current
        .map((item) => item.product.id === productId ? { ...item, quantity: item.quantity + delta } : item)
        .filter((item) => item.quantity > 0)
    );
  }

  function checkout() {
    Alert.alert(
      "Checkout is not connected yet",
      `Your bag total is ${money(total)}. Connect a payment provider and backend before accepting real orders.`
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#10110F" />
      <View style={styles.header}>
        <View>
          <Text style={styles.brand}>DRIPZONE<Text style={styles.brandDot}>.</Text></Text>
          <Text style={styles.tagline}>YOUR STYLE. YOUR ZONE.</Text>
        </View>
        <TouchableOpacity style={styles.bagButton} onPress={() => setShowCart((v) => !v)}>
          <Text style={styles.bagButtonText}>{showCart ? "SHOP" : `BAG (${itemCount})`}</Text>
        </TouchableOpacity>
      </View>

      {showCart ? (
        <ScrollView contentContainerStyle={styles.page}>
          <Text style={styles.eyebrow}>YOUR SELECTION</Text>
          <Text style={styles.pageTitle}>Shopping bag</Text>
          {cart.length === 0 ? (
            <View style={styles.emptyCart}>
              <Text style={styles.emptyIcon}>◇</Text>
              <Text style={styles.emptyTitle}>Your bag is empty</Text>
              <Text style={styles.muted}>Find your next everyday favorite.</Text>
              <TouchableOpacity style={styles.primaryButton} onPress={() => setShowCart(false)}>
                <Text style={styles.primaryButtonText}>EXPLORE THE DROP</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <>
              {cart.map(({ product, quantity }) => (
                <View key={product.id} style={styles.cartRow}>
                  <ProductArt product={product} compact />
                  <View style={styles.cartDetails}>
                    <Text style={styles.productName}>{product.name}</Text>
                    <Text style={styles.muted}>{product.category}</Text>
                    <Text style={styles.price}>{money(product.price)}</Text>
                    <View style={styles.quantityControls}>
                      <TouchableOpacity style={styles.quantityButton} onPress={() => changeQuantity(product.id, -1)}>
                        <Text style={styles.quantityButtonText}>−</Text>
                      </TouchableOpacity>
                      <Text style={styles.quantity}>{quantity}</Text>
                      <TouchableOpacity style={styles.quantityButton} onPress={() => changeQuantity(product.id, 1)}>
                        <Text style={styles.quantityButtonText}>+</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => changeQuantity(product.id, -quantity)}>
                        <Text style={styles.removeText}>Remove</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              ))}
              <View style={styles.summary}>
                <SummaryRow label="Subtotal" value={money(subtotal)} />
                <SummaryRow label="Shipping" value={shipping === 0 ? (subtotal === 0 ? "$0.00" : "FREE") : money(shipping)} />
                {subtotal > 0 && subtotal < 100 && <Text style={styles.shippingHint}>Spend {money(100 - subtotal)} more for free shipping.</Text>}
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total</Text>
                  <Text style={styles.totalPrice}>{money(total)}</Text>
                </View>
                <TouchableOpacity style={styles.primaryButton} onPress={checkout}>
                  <Text style={styles.primaryButtonText}>CONTINUE TO CHECKOUT</Text>
                </TouchableOpacity>
                <Text style={styles.checkoutNote}>Taxes are calculated at checkout. Payments are not enabled in this starter.</Text>
              </View>
            </>
          )}
        </ScrollView>
      ) : (
        <ScrollView contentContainerStyle={styles.page}>
          <View style={styles.hero}>
            <View style={styles.heroCopy}>
              <Text style={styles.eyebrow}>THE EVERYDAY STREETWEAR DROP</Text>
              <Text style={styles.heroTitle}>MOVE IN{`\n`}YOUR ZONE.</Text>
              <Text style={styles.heroBody}>Clean essentials. Confident energy. Built for your rotation.</Text>
              <TouchableOpacity style={styles.heroButton} onPress={() => setCategory("All")}>
                <Text style={styles.heroButtonText}>SHOP THE DROP ↘</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.heroStamp}>
              <Text style={styles.stampTop}>DZ</Text>
              <Text style={styles.stampBottom}>EST. 2026</Text>
            </View>
          </View>

          <View style={styles.sectionHeading}>
            <View>
              <Text style={styles.eyebrow}>CURATED FOR THE CULTURE</Text>
              <Text style={styles.sectionTitle}>Shop the drop</Text>
            </View>
            <Text style={styles.productCount}>{visibleProducts.length} ITEMS</Text>
          </View>

          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filters}>
            {CATEGORIES.map((item) => (
              <TouchableOpacity
                key={item}
                onPress={() => setCategory(item)}
                style={[styles.filter, category === item && styles.filterActive]}
              >
                <Text style={[styles.filterText, category === item && styles.filterTextActive]}>{item}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <View style={styles.productGrid}>
            {visibleProducts.map((product) => (
              <View key={product.id} style={styles.productCard}>
                <ProductArt product={product} />
                {product.tag && <Text style={styles.productTag}>{product.tag}</Text>}
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productDescription}>{product.description}</Text>
                <View style={styles.productBottom}>
                  <Text style={styles.price}>{money(product.price)}</Text>
                  <TouchableOpacity style={styles.addButton} onPress={() => addToCart(product)}>
                    <Text style={styles.addButtonText}>+ ADD</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
          <View style={styles.footer}>
            <Text style={styles.footerBrand}>DRIPZONE.</Text>
            <Text style={styles.footerText}>FIND YOUR FIT. OWN YOUR ZONE.</Text>
            <Text style={styles.footerFine}>Starter catalog • Prices in USD • Edit products before launch</Text>
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

function ProductArt({ product, compact = false }: { product: Product; compact?: boolean }) {
  return (
    <View style={[styles.productArt, { backgroundColor: product.color }, compact && styles.productArtCompact]}>
      <View style={styles.artTopLine} />
      <Text style={[styles.artLogo, compact && styles.artLogoCompact]}>DRIP<Text style={styles.artLogoDark}>ZONE</Text></Text>
      <Text style={styles.artCategory}>{product.category.toUpperCase()}</Text>
      <View style={styles.artCircle} />
      {!compact && <Text style={styles.artCode}>DZ / 026</Text>}
    </View>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.summaryRow}>
      <Text style={styles.muted}>{label}</Text>
      <Text style={styles.summaryValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F3EE" },
  header: { backgroundColor: "#10110F", paddingHorizontal: 20, paddingVertical: 17, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  brand: { color: "#F8F7F2", fontSize: 24, fontWeight: "900", letterSpacing: 2 },
  brandDot: { color: "#C5F467" },
  tagline: { color: "#A7A89F", fontSize: 9, letterSpacing: 2, marginTop: 3 },
  bagButton: { borderWidth: 1, borderColor: "#C5F467", paddingVertical: 10, paddingHorizontal: 13 },
  bagButtonText: { color: "#C5F467", fontSize: 11, fontWeight: "800", letterSpacing: 1 },
  page: { padding: 18, paddingBottom: 30 },
  hero: { backgroundColor: "#C5F467", minHeight: 238, padding: 20, flexDirection: "row", justifyContent: "space-between", overflow: "hidden" },
  heroCopy: { flex: 1, paddingRight: 4 },
  eyebrow: { fontSize: 9, letterSpacing: 1.7, fontWeight: "800", color: "#555A4C" },
  heroTitle: { color: "#11130E", fontSize: 39, lineHeight: 39, fontWeight: "900", letterSpacing: -1.8, marginTop: 16 },
  heroBody: { color: "#33382C", fontSize: 12, lineHeight: 18, maxWidth: 210, marginTop: 10 },
  heroButton: { backgroundColor: "#11130E", paddingVertical: 12, paddingHorizontal: 14, alignSelf: "flex-start", marginTop: 18 },
  heroButtonText: { color: "#C5F467", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  heroStamp: { width: 80, height: 80, borderWidth: 2, borderColor: "#11130E", borderRadius: 40, alignItems: "center", justifyContent: "center", alignSelf: "center", transform: [{ rotate: "-12deg" }] },
  stampTop: { color: "#11130E", fontSize: 31, fontWeight: "900", letterSpacing: -2 },
  stampBottom: { color: "#11130E", fontSize: 7, fontWeight: "900", letterSpacing: 1 },
  sectionHeading: { marginTop: 29, flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between" },
  sectionTitle: { color: "#171914", fontSize: 26, fontWeight: "900", letterSpacing: -0.8, marginTop: 4 },
  productCount: { color: "#73766B", fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  filters: { paddingTop: 15, paddingBottom: 17, gap: 8 },
  filter: { paddingHorizontal: 14, paddingVertical: 9, borderWidth: 1, borderColor: "#D8D8CF", backgroundColor: "#F9F8F4" },
  filterActive: { backgroundColor: "#171914", borderColor: "#171914" },
  filterText: { color: "#54574E", fontSize: 11, fontWeight: "700" },
  filterTextActive: { color: "#C5F467" },
  productGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", rowGap: 18 },
  productCard: { width: "48.2%", marginBottom: 2 },
  productArt: { height: 172, alignItems: "center", justifyContent: "center", overflow: "hidden", position: "relative" },
  productArtCompact: { width: 104, height: 112, flexShrink: 0 },
  artTopLine: { position: "absolute", top: 13, left: 13, right: 13, height: 1, backgroundColor: "rgba(20,22,17,0.2)" },
  artLogo: { fontSize: 22, fontWeight: "900", color: "#22251E", letterSpacing: -1.5 },
  artLogoCompact: { fontSize: 14 },
  artLogoDark: { color: "#F5F3EE" },
  artCategory: { color: "#33372D", fontSize: 8, fontWeight: "900", letterSpacing: 2, marginTop: 5 },
  artCircle: { position: "absolute", width: 118, height: 118, borderRadius: 59, borderWidth: 1, borderColor: "rgba(30,33,25,0.15)", right: -43, bottom: -38 },
  artCode: { position: "absolute", bottom: 10, left: 12, color: "#33372D", fontSize: 8, fontWeight: "800", letterSpacing: 1 },
  productTag: { color: "#6C7E3D", fontSize: 8, fontWeight: "900", letterSpacing: 1.2, marginTop: 9 },
  productName: { color: "#191B16", fontSize: 13, fontWeight: "800", marginTop: 9 },
  productDescription: { color: "#77796F", fontSize: 10, marginTop: 4, lineHeight: 14 },
  productBottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 10 },
  price: { color: "#191B16", fontSize: 14, fontWeight: "900" },
  addButton: { backgroundColor: "#171914", paddingVertical: 8, paddingHorizontal: 10 },
  addButtonText: { color: "#C5F467", fontSize: 9, fontWeight: "900", letterSpacing: 0.7 },
  footer: { marginTop: 35, paddingTop: 22, borderTopWidth: 1, borderTopColor: "#DCDCD3", alignItems: "center" },
  footerBrand: { color: "#171914", fontSize: 20, fontWeight: "900", letterSpacing: 2 },
  footerText: { color: "#73766B", fontSize: 9, fontWeight: "800", letterSpacing: 1.5, marginTop: 5 },
  footerFine: { color: "#8B8D83", fontSize: 9, textAlign: "center", marginTop: 14 },
  emptyCart: { alignItems: "center", paddingVertical: 55 },
  emptyIcon: { color: "#A0B95E", fontSize: 52 },
  emptyTitle: { color: "#191B16", fontSize: 20, fontWeight: "900", marginTop: 10 },
  muted: { color: "#77796F", fontSize: 11, lineHeight: 17 },
  primaryButton: { backgroundColor: "#171914", alignItems: "center", paddingVertical: 15, paddingHorizontal: 18, marginTop: 20 },
  primaryButtonText: { color: "#C5F467", fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  cartRow: { flexDirection: "row", gap: 13, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: "#DFDFD6" },
  cartDetails: { flex: 1, justifyContent: "center" },
  quantityControls: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 9 },
  quantityButton: { width: 28, height: 28, borderWidth: 1, borderColor: "#D0D1C7", alignItems: "center", justifyContent: "center" },
  quantityButtonText: { color: "#171914", fontSize: 17, fontWeight: "600" },
  quantity: { color: "#171914", fontSize: 12, fontWeight: "800", minWidth: 12, textAlign: "center" },
  removeText: { color: "#7A5148", fontSize: 10, textDecorationLine: "underline", marginLeft: 4 },
  pageTitle: { color: "#171914", fontSize: 29, fontWeight: "900", marginTop: 5, marginBottom: 8 },
  summary: { backgroundColor: "#ECECE3", padding: 16, marginTop: 20 },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 6 },
  summaryValue: { color: "#171914", fontSize: 12, fontWeight: "700" },
  shippingHint: { color: "#6C7E3D", fontSize: 10, marginTop: 3 },
  totalRow: { borderTopWidth: 1, borderTopColor: "#D0D1C7", marginTop: 10, paddingTop: 14, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  totalLabel: { color: "#171914", fontSize: 15, fontWeight: "900" },
  totalPrice: { color: "#171914", fontSize: 20, fontWeight: "900" },
  checkoutNote: { color: "#77796F", fontSize: 9, lineHeight: 14, textAlign: "center", marginTop: 12 },
});
